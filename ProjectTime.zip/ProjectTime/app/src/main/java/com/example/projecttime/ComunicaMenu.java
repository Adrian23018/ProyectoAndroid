package com.example.projecttime;

public interface ComunicaMenu {

    public void menu(int queboton);

}
